<div class="alert alert-info">
  <strong><?php echo esc_html__('Info!', 'listingpro'); ?></strong> <?php echo esc_html__('Your listing is pending! Please proceed to make it publish', 'listingpro'); ?>
</div>