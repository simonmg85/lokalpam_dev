(function( $ ) {
    $(function() {
        $('.color-field').wpColorPicker();
    });

})( jQuery );
